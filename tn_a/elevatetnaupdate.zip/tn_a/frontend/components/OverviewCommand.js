import { useMemo } from 'react'
import {
  Activity, Target, Layers, Clock,
  AlertTriangle, Flame, Flag, TrendingUp, Quote, ChevronRight,
} from 'lucide-react'
import { TOKENS, personaColor, priorityColor, tagColor } from '../utils/colors'
import {
  personasInData, filterByArchetype, lensMetrics, computeInsights, evidenceQuotes, parsePipes,
} from '../utils/aggregations'
import { useCountUp } from '../utils/useCountUp'
import SankeyFlow from './SankeyFlow'

const INSIGHT_ICON = { alert: AlertTriangle, target: Target, flame: Flame, flag: Flag, trend: TrendingUp }
const TONE = {
  risk: { color: '#C0392B', bg: '#C0392B0d' },
  focus: { color: '#1A8A8F', bg: '#1A8A8F0d' },
  info: { color: '#0A3D62', bg: '#0A3D620d' },
}

export default function OverviewCommand({ state }) {
  const { rows, lens, setLens, openDrawer, setView } = state

  const archetypes = useMemo(() => personasInData(rows), [rows])
  const archMeta = useMemo(
    () => archetypes.map((a) => ({ name: a, color: personaColor(a), count: rows.filter((r) => r.Persona === a).length })),
    [archetypes, rows],
  )
  const lensRows = useMemo(() => filterByArchetype(rows, lens), [rows, lens])
  const m = useMemo(() => lensMetrics(lensRows), [lensRows])
  const insights = useMemo(() => computeInsights(lensRows), [lensRows])
  const quotes = useMemo(() => evidenceQuotes(lensRows, 3), [lensRows])

  const openTag = (tag) => {
    const rs = lensRows.filter((r) => parsePipes(r.Tags).includes(tag))
    if (!rs.length) return
    openDrawer({ type: 'Signal', title: `${tag} signals`, subtitle: `${rs.length} record${rs.length > 1 ? 's' : ''}`, accent: tagColor(tag), rows: rs })
  }
  const openQuote = (row) => {
    openDrawer({ type: 'Evidence', title: row.Change_Component, subtitle: `${row.Persona} · ${row.Role}`, accent: personaColor(row.Persona), rows: [row] })
  }

  const focusLabel = lens || 'All archetypes'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Title */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
        <div>
          <h1 className="font-serif-head" style={{ fontSize: 30, margin: 0, color: TOKENS.navy, fontWeight: 600 }}>
            Change Readiness Command Center
          </h1>
          <p style={{ margin: '4px 0 0', fontSize: 13.5, color: TOKENS.subtle }}>
            How you are impacted &nbsp;→&nbsp; what to focus on &nbsp;→&nbsp; who to train, on what.
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#1A8A8F' }} />
          <span className="font-mono-num" style={{ fontSize: 11, color: TOKENS.subtle, letterSpacing: 0.4 }}>
            LENS · {focusLabel.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Archetype lens bar */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <LensChip active={!lens} onClick={() => setLens(null)} color={TOKENS.navy} label="All archetypes" count={rows.length} allChip />
        {archMeta.map((a) => (
          <LensChip key={a.name} active={lens === a.name} onClick={() => setLens(a.name)} color={a.color} label={a.name} count={a.count} />
        ))}
      </div>

      {/* Command row: readiness + risk, then KPI tiles */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(240px, 300px) 1fr', gap: 14, alignItems: 'stretch' }}>
        <ReadinessCard metrics={m} onTag={openTag} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          <Stat icon={Activity} accent="#0A3D62" label="Training Needs" value={m.needs} onClick={null} />
          <Stat icon={Layers} accent="#1A8A8F" label="Learning Modules" value={m.modules} onClick={() => setView('library')} />
          <Stat icon={Clock} accent="#A65D3D" label="Training Hours" value={m.hours} suffix="h" onClick={() => setView('journey')} />
          <Stat icon={AlertTriangle} accent="#C0392B" label="Critical Needs" value={m.critical} onClick={null} />
        </div>
      </div>

      {/* Insight callouts */}
      {insights.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(insights.length, 4)}, 1fr)`, gap: 12 }}>
          {insights.slice(0, 4).map((ins, i) => (
            <InsightCard key={i} insight={ins} />
          ))}
        </div>
      )}

      {/* Flow */}
      <section style={{ background: '#fff', border: `1px solid ${TOKENS.border}`, borderRadius: 8, padding: 20, boxShadow: '0 2px 12px rgba(10,61,98,0.06)' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', marginBottom: 6 }}>
          <div>
            <h2 className="font-serif-head" style={{ fontSize: 20, margin: 0, color: TOKENS.navy }}>
              The lineage — Impact → Need → Module
            </h2>
            <p style={{ margin: '4px 0 0', fontSize: 12.5, color: TOKENS.subtle }}>
              Hover any node to trace its full path. Click to open its source records. {lens ? `Filtered to ${lens}.` : 'Select an archetype above to focus.'}
            </p>
          </div>
          <Legend />
        </div>
        <SankeyFlow rows={lensRows} openDrawer={openDrawer} />
      </section>

      {/* Evidence */}
      {quotes.length > 0 && (
        <section>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <Quote size={15} color={TOKENS.navy} />
            <span className="font-serif-head" style={{ fontSize: 17, color: TOKENS.navy }}>The evidence layer</span>
            <span style={{ fontSize: 12, color: TOKENS.subtle }}>— every need traces to a verbatim quote</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(quotes.length, 3)}, 1fr)`, gap: 12 }}>
            {quotes.map((row) => (
              <QuoteCard key={row.Row_ID} row={row} onClick={() => openQuote(row)} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

function LensChip({ active, onClick, color, label, count, allChip }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px', borderRadius: 20,
        border: `1.5px solid ${active ? color : TOKENS.border}`,
        background: active ? color : '#fff',
        color: active ? '#fff' : '#333',
        cursor: 'pointer', fontSize: 12.5, fontWeight: active ? 700 : 500,
        transition: 'all 160ms ease', fontFamily: 'inherit',
      }}
    >
      {!allChip && <span style={{ width: 9, height: 9, borderRadius: '50%', background: active ? '#fff' : color, flexShrink: 0 }} />}
      <span>{label}</span>
      <span className="font-mono-num" style={{
        fontSize: 11, fontWeight: 700, padding: '0 6px', borderRadius: 8,
        background: active ? 'rgba(255,255,255,0.22)' : '#F1F1EC', color: active ? '#fff' : TOKENS.subtle,
      }}>
        {count}
      </span>
    </button>
  )
}

function ReadinessCard({ metrics, onTag }) {
  const pct = useCountUp(metrics.readiness)
  const rounded = Math.round(pct)
  const R = 42
  const C = 2 * Math.PI * R
  const dash = (rounded / 100) * C
  const color = rounded >= 70 ? '#1A8A8F' : rounded >= 50 ? '#E67E22' : '#C0392B'
  return (
    <div style={{ background: '#fff', border: `1px solid ${TOKENS.border}`, borderRadius: 8, padding: 16, boxShadow: '0 2px 12px rgba(10,61,98,0.06)', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase', color: TOKENS.subtle }}>
        Baseline readiness
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <svg width="104" height="104" viewBox="0 0 104 104" style={{ flexShrink: 0 }}>
          <circle cx="52" cy="52" r={R} fill="none" stroke="#EFEFE9" strokeWidth="10" />
          <circle cx="52" cy="52" r={R} fill="none" stroke={color} strokeWidth="10" strokeLinecap="round"
            strokeDasharray={`${dash} ${C}`} transform="rotate(-90 52 52)" style={{ transition: 'stroke 300ms ease' }} />
          <text x="52" y="50" textAnchor="middle" fontSize="24" fontWeight="700" fill={TOKENS.navy} fontFamily="JetBrains Mono, monospace">
            {rounded}
          </text>
          <text x="52" y="66" textAnchor="middle" fontSize="10" fill="#9a9a92">of target</text>
        </svg>
        <div style={{ fontSize: 12, color: TOKENS.subtle, lineHeight: 1.5 }}>
          Current proficiency vs. target across{' '}
          <strong style={{ color: '#333' }}>{metrics.needs}</strong> need{metrics.needs !== 1 ? 's' : ''}.
        </div>
      </div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <RiskPill label="Pressure" count={metrics.pressure} color="#E67E22" onClick={() => onTag('Pressure')} />
        <RiskPill label="Friction" count={metrics.friction} color="#6B3F5E" onClick={() => onTag('Friction')} />
        <RiskPill label="Gap" count={metrics.gap} color="#C0392B" onClick={() => onTag('Gap')} />
      </div>
    </div>
  )
}

function RiskPill({ label, count, color, onClick }) {
  const disabled = !count
  return (
    <button
      onClick={disabled ? undefined : onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 6, padding: '4px 9px', borderRadius: 6,
        border: `1px solid ${disabled ? TOKENS.border : color + '55'}`,
        background: disabled ? '#FAFAF7' : color + '12',
        color: disabled ? '#c3c3ba' : color, cursor: disabled ? 'default' : 'pointer',
        fontSize: 11.5, fontWeight: 600, fontFamily: 'inherit',
      }}
    >
      <span className="font-mono-num" style={{ fontWeight: 700 }}>{count}</span>
      {label}
    </button>
  )
}

function Stat({ icon: Icon, accent, label, value, suffix, onClick }) {
  const v = useCountUp(value)
  const clickable = !!onClick
  return (
    <div
      onClick={onClick || undefined}
      style={{
        position: 'relative', background: '#fff', border: `1px solid ${TOKENS.border}`, borderRadius: 8,
        padding: '14px 14px 14px 16px', boxShadow: '0 2px 12px rgba(10,61,98,0.06)',
        cursor: clickable ? 'pointer' : 'default', overflow: 'hidden',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: 96,
      }}
      onMouseEnter={(e) => clickable && (e.currentTarget.style.boxShadow = '0 8px 22px rgba(10,61,98,0.13)')}
      onMouseLeave={(e) => clickable && (e.currentTarget.style.boxShadow = '0 2px 12px rgba(10,61,98,0.06)')}
    >
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 4, background: accent }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Icon size={16} color={accent} />
        {clickable && <ChevronRight size={14} color="#c3c3ba" />}
      </div>
      <div>
        <div className="font-mono-num" style={{ fontSize: 30, fontWeight: 700, color: TOKENS.navy, lineHeight: 1 }}>
          {Math.round(v)}{suffix || ''}
        </div>
        <div style={{ fontSize: 12, color: TOKENS.subtle, marginTop: 4 }}>{label}</div>
      </div>
    </div>
  )
}

function InsightCard({ insight }) {
  const Icon = INSIGHT_ICON[insight.icon] || Flag
  const tone = TONE[insight.tone] || TONE.info
  return (
    <div style={{ background: '#fff', border: `1px solid ${TOKENS.border}`, borderRadius: 8, padding: 14, boxShadow: '0 2px 12px rgba(10,61,98,0.06)', display: 'flex', gap: 11 }}>
      <div style={{ width: 30, height: 30, borderRadius: 8, background: tone.bg, color: tone.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon size={16} />
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase', color: tone.color }}>
          {insight.label}
        </div>
        <div style={{ fontSize: 12.5, color: '#333', lineHeight: 1.45, marginTop: 3 }}>{insight.text}</div>
      </div>
    </div>
  )
}

function QuoteCard({ row, onClick }) {
  const color = personaColor(row.Persona)
  return (
    <div
      onClick={onClick}
      style={{
        background: '#fff', border: `1px solid ${TOKENS.border}`, borderLeft: `4px solid ${color}`,
        borderRadius: 8, padding: '14px 16px', boxShadow: '0 2px 12px rgba(10,61,98,0.06)', cursor: 'pointer',
        display: 'flex', flexDirection: 'column', gap: 10, transition: 'transform 160ms ease, box-shadow 160ms ease',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 10px 24px rgba(10,61,98,0.13)' }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 2px 12px rgba(10,61,98,0.06)' }}
    >
      <p className="font-serif-head" style={{ margin: 0, fontStyle: 'italic', fontSize: 15, color: '#2a2a2a', lineHeight: 1.4 }}>
        “{row.Source_Quote}”
      </p>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, color: TOKENS.subtle }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
        <span style={{ fontWeight: 600, color: '#444' }}>{row.Persona}</span>
        <span>·</span>
        <span className="font-mono-num">{row.Source_Run}</span>
      </div>
    </div>
  )
}

function Legend() {
  return (
    <div style={{ display: 'flex', gap: 14, fontSize: 11, color: TOKENS.subtle, alignItems: 'center' }}>
      <LegendDot color={TOKENS.navy} label="Category" />
      <LegendDot color="#1A8A8F" label="Archetype" />
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
        <span style={{ width: 11, height: 11, borderRadius: 3, background: '#fff', border: `3px solid ${priorityColor('Critical')}` }} />
        Module
      </span>
    </div>
  )
}
function LegendDot({ color, label }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
      <span style={{ width: 11, height: 11, borderRadius: 3, background: color }} />
      {label}
    </span>
  )
}
