import { useEffect, useMemo, useState } from 'react'
import { TOKENS, personaColor, priorityColor } from '../utils/colors'
import { buildSankey, lineageForNode, rowsForNode } from '../utils/aggregations'

const COL = {
  leftX: 16,
  leftW: 190,
  midX: 425,
  midW: 190,
  rightX: 828,
  rightW: 196,
  width: 1040,
}
const PAD_TOP = 30
const GAP = 12
const MIN_H = 30

function layoutColumn(nodes, valueKey, height) {
  const total = nodes.reduce((a, n) => a + (n[valueKey] || 0), 0) || 1
  const usable = height - PAD_TOP - 14 - GAP * (nodes.length - 1)
  const minTotal = MIN_H * nodes.length
  const flex = Math.max(usable - minTotal, 0)
  let y = PAD_TOP
  return nodes.map((n) => {
    const h = MIN_H + flex * ((n[valueKey] || 0) / total)
    const node = { ...n, y, h }
    y += h + GAP
    return node
  })
}

// Stack a link set into proportional vertical slices at each node edge.
function sliceLinks(links, nodeById, side) {
  const groupKey = side === 'out' ? 'source' : 'target'
  const otherKey = side === 'out' ? 'target' : 'source'
  const groups = {}
  for (const l of links) {
    if (!groups[l[groupKey]]) groups[l[groupKey]] = []
    groups[l[groupKey]].push(l)
  }
  const slices = {}
  for (const [nid, ls] of Object.entries(groups)) {
    const node = nodeById[nid]
    if (!node) continue
    const sum = ls.reduce((a, l) => a + l.weight, 0) || 1
    ls.sort((a, b) => (nodeById[a[otherKey]]?.y ?? 0) - (nodeById[b[otherKey]]?.y ?? 0))
    let off = 0
    for (const l of ls) {
      const h = (l.weight / sum) * node.h
      slices[l.__id + ':' + side] = { y: node.y + off, h }
      off += h
    }
  }
  return slices
}

function ribbonPath(sx, sSlice, tx, tSlice) {
  const sy0 = sSlice.y
  const sy1 = sSlice.y + sSlice.h
  const ty0 = tSlice.y
  const ty1 = tSlice.y + tSlice.h
  const mx = (sx + tx) / 2
  return `M ${sx},${sy0} C ${mx},${sy0} ${mx},${ty0} ${tx},${ty0} L ${tx},${ty1} C ${mx},${ty1} ${mx},${sy1} ${sx},${sy1} Z`
}

export default function SankeyFlow({ rows, openDrawer }) {
  const [hovered, setHovered] = useState(null)
  const [shown, setShown] = useState(false)

  const sankey = useMemo(() => buildSankey(rows), [rows])
  const height = Math.max(520, sankey.moduleNodes.length * 34 + 70)

  const cats = useMemo(() => layoutColumn(sankey.categoryNodes, 'count', height), [sankey, height])
  const personas = useMemo(() => layoutColumn(sankey.personaNodes, 'count', height), [sankey, height])
  const mods = useMemo(() => layoutColumn(sankey.moduleNodes, 'hours', height), [sankey, height])

  const nodeById = useMemo(() => {
    const m = {}
    cats.forEach((n) => (m[n.id] = { ...n, col: 'left' }))
    personas.forEach((n) => (m[n.id] = { ...n, col: 'mid' }))
    mods.forEach((n) => (m[n.id] = { ...n, col: 'right' }))
    return m
  }, [cats, personas, mods])

  const cpLinks = useMemo(
    () => sankey.catPersonaLinks.map((l) => ({ ...l, __id: `${l.source}>${l.target}` })),
    [sankey],
  )
  const pmLinks = useMemo(
    () => sankey.personaModuleLinks.map((l) => ({ ...l, __id: `${l.source}>${l.target}` })),
    [sankey],
  )

  const cpOut = useMemo(() => sliceLinks(cpLinks, nodeById, 'out'), [cpLinks, nodeById])
  const cpIn = useMemo(() => sliceLinks(cpLinks, nodeById, 'in'), [cpLinks, nodeById])
  const pmOut = useMemo(() => sliceLinks(pmLinks, nodeById, 'out'), [pmLinks, nodeById])
  const pmIn = useMemo(() => sliceLinks(pmLinks, nodeById, 'in'), [pmLinks, nodeById])

  const activeSet = useMemo(() => (hovered ? lineageForNode(sankey, hovered) : null), [hovered, sankey])

  useEffect(() => {
    setShown(false)
    const id = requestAnimationFrame(() => setShown(true))
    return () => cancelAnimationFrame(id)
  }, [rows])

  const nodeOpacity = (id) => (!activeSet ? 1 : activeSet.has(id) ? 1 : 0.22)
  const linkBase = (s, t) => {
    if (!activeSet) return 0.5
    return activeSet.has(s) && activeSet.has(t) ? 0.9 : 0.06
  }

  const openNode = (id) => {
    const node = nodeById[id]
    const nodeRows = rowsForNode(rows, id)
    const typeLabel = node.col === 'left' ? 'Change Category' : node.col === 'mid' ? 'Archetype' : 'Module'
    openDrawer({
      type: typeLabel,
      title: node.label,
      subtitle: `${nodeRows.length} record${nodeRows.length > 1 ? 's' : ''} on this lineage`,
      accent: node.col === 'mid' ? personaColor(node.label) : node.color || TOKENS.navy,
      rows: nodeRows,
    })
  }

  return (
    <div style={{ overflowX: 'auto' }}>
      <svg
        viewBox={`0 0 ${COL.width} ${height}`}
        width="100%"
        style={{ minWidth: 900, display: 'block' }}
        onMouseLeave={() => setHovered(null)}
      >
        <defs>
          {cpLinks.map((l, i) => {
            const t = nodeById[l.target]
            return (
              <linearGradient key={`gcp${i}`} id={`gcp${i}`} x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={TOKENS.navy} />
                <stop offset="100%" stopColor={personaColor(t?.label)} />
              </linearGradient>
            )
          })}
          {pmLinks.map((l, i) => {
            const s = nodeById[l.source]
            const t = nodeById[l.target]
            return (
              <linearGradient key={`gpm${i}`} id={`gpm${i}`} x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={personaColor(s?.label)} />
                <stop offset="100%" stopColor={priorityColor(t?.priority)} />
              </linearGradient>
            )
          })}
        </defs>

        <ColHeader x={COL.leftX} w={COL.leftW} label="IMPACT" sub="by change category" />
        <ColHeader x={COL.midX} w={COL.midW} label="TRAINING NEED" sub="by archetype" />
        <ColHeader x={COL.rightX} w={COL.rightW} label="LEARNING MODULE" sub="by hours" />

        {/* Ribbons: category → archetype */}
        {cpLinks.map((l, i) => {
          const s = cpOut[l.__id + ':out']
          const t = cpIn[l.__id + ':in']
          if (!s || !t) return null
          const op = shown ? linkBase(l.source, l.target) : 0
          return (
            <path
              key={`cp${i}`}
              d={ribbonPath(COL.leftX + COL.leftW, s, COL.midX, t)}
              fill={`url(#gcp${i})`}
              opacity={op}
              style={{ transition: `opacity 620ms ease ${i * 12}ms` }}
            />
          )
        })}

        {/* Ribbons: archetype → module */}
        {pmLinks.map((l, i) => {
          const s = pmOut[l.__id + ':out']
          const t = pmIn[l.__id + ':in']
          if (!s || !t) return null
          const op = shown ? linkBase(l.source, l.target) : 0
          return (
            <path
              key={`pm${i}`}
              d={ribbonPath(COL.midX + COL.midW, s, COL.rightX, t)}
              fill={`url(#gpm${i})`}
              opacity={op}
              style={{ transition: `opacity 620ms ease ${i * 10}ms` }}
            />
          )
        })}

        {cats.map((n) => (
          <Node key={n.id} x={COL.leftX} w={COL.leftW} n={n} fill={TOKENS.navy} label={n.label}
            badge={`${n.count}`} align="left" opacity={nodeOpacity(n.id)} shown={shown}
            onHover={() => setHovered(n.id)} onClick={() => openNode(n.id)} />
        ))}
        {personas.map((n) => (
          <Node key={n.id} x={COL.midX} w={COL.midW} n={n} fill={personaColor(n.label)} label={n.label}
            badge={`${n.count}`} align="center" opacity={nodeOpacity(n.id)} shown={shown}
            onHover={() => setHovered(n.id)} onClick={() => openNode(n.id)} />
        ))}
        {mods.map((n) => (
          <Node key={n.id} x={COL.rightX} w={COL.rightW} n={n} fill="#fff" stroke={priorityColor(n.priority)}
            textColor="#222" label={n.label} badge={`${n.hours}h`} align="right" opacity={nodeOpacity(n.id)}
            shown={shown} onHover={() => setHovered(n.id)} onClick={() => openNode(n.id)} />
        ))}
      </svg>
    </div>
  )
}

function Node({ x, w, n, fill, stroke, textColor, label, badge, align, opacity, shown, onHover, onClick }) {
  const small = n.h < 34
  const tColor = textColor || '#fff'
  return (
    <g
      style={{ cursor: 'pointer', transition: 'opacity 500ms ease' }}
      opacity={shown ? opacity : 0}
      onMouseEnter={onHover}
      onClick={onClick}
    >
      <rect x={x} y={n.y} width={w} height={n.h} rx={7} fill={fill}
        stroke={stroke || 'rgba(0,0,0,0.06)'} strokeWidth={stroke ? 2.5 : 1} />
      <foreignObject x={x + 9} y={n.y} width={w - 18} height={n.h}>
        <div style={{
          height: '100%', display: 'flex', flexDirection: small ? 'row' : 'column',
          alignItems: align === 'center' ? 'center' : 'flex-start', justifyContent: 'center',
          gap: small ? 6 : 2, textAlign: align === 'center' ? 'center' : 'left', overflow: 'hidden',
        }}>
          <span style={{
            fontSize: 11.5, fontWeight: 600, color: tColor, lineHeight: 1.15,
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
          }}>
            {label}
          </span>
          <span className="font-mono-num" style={{
            fontSize: 10.5, fontWeight: 700, color: textColor ? '#777' : 'rgba(255,255,255,0.85)',
          }}>
            {badge}
          </span>
        </div>
      </foreignObject>
    </g>
  )
}

function ColHeader({ x, label, sub }) {
  return (
    <g>
      <text x={x} y={11} fontSize="11" fontWeight="700" fill={TOKENS.navy} letterSpacing="0.8">
        {label}
      </text>
      <text x={x} y={23} fontSize="9.5" fill="#9a9a92" letterSpacing="0.3">
        {sub}
      </text>
    </g>
  )
}
