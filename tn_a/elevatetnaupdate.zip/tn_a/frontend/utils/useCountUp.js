import { useEffect, useRef, useState } from 'react'

// Animate a number from 0 → target with an ease-out cubic. Replays when target changes.
export function useCountUp(target, duration = 850) {
  const [val, setVal] = useState(target)
  const raf = useRef(0)
  useEffect(() => {
    let start = null
    const from = 0
    cancelAnimationFrame(raf.current)
    const tick = (t) => {
      if (start === null) start = t
      const p = Math.min((t - start) / duration, 1)
      const eased = 1 - Math.pow(1 - p, 3)
      setVal(from + (target - from) * eased)
      if (p < 1) raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [target, duration])
  return val
}
