# ELEVATE TNA — data tables (Airtable import)

Import-ready CSVs generated from the single denormalized wide table
(`TNA/src/data/tna_master.json` — 29 Training Needs). Upload these into the
base behind the interface where the `tn_a` extension lives, via
**Airtable → Add table → Import data → CSV file**.

| File | Rows | What it is |
|---|---|---|
| `01_TNA_Master.csv` | 29 | **The bind target.** Full wide table — every column. |
| `02_Impacts.csv` | 29 | CIA impact context, one row per `Impact_ID`. |
| `03_Training_Needs.csv` | 29 | TNA detail, one row per `TNA_ID`. |
| `04_Modules.csv` | 17 | Distinct Learning Modules, by `Module_ID`. |
| `05_Journeys.csv` | 5 | Persona/archetype journeys, by `Journey_ID`. |

## Which table the extension binds to

The dashboard renders from its own bundled data, but the **"Open in Airtable"**
action on a record needs a real table. The extension looks for a table
containing an id column named **`Row_ID`**, then **`TNA_ID`**, then
**`Impact_ID`** (first match wins). `01_TNA_Master.csv` has `Row_ID`, so it is
the natural bind target — import it and native record expand works with no
config change.

If you prefer to bind to a different table, set the table name / key fields in
`tn_a/frontend/state/useAirtableRecords.js` (`RECORD_SOURCE`).

## Minimal setup (fastest)

1. Import **`01_TNA_Master.csv`** into the base.
2. Open the interface with the `tn_a` extension.
3. Click any detailed record in the drawer → it expands the native Airtable
   record.

## Relational setup (optional, cleaner base)

Import all five. In Airtable, convert the id columns to **linked-record**
fields to wire them up:
`Training_Needs.Impact_ID → Impacts`, `Training_Needs.Module_ID → Modules`,
`Training_Needs → Journeys`. Then point `RECORD_SOURCE.tableName` at
`Training_Needs`.

> Note: CSVs are regenerated from `tna_master.json`. If the source data
> changes, re-run the generator to refresh these.
